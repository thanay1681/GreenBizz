import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/scheduler.dart';
import 'package:anabathula_s_application2/theme/theme_helper.dart';
import 'package:anabathula_s_application2/routes/app_routes.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_signin/screens/signin_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
  ]);

  ///Please update theme as per your need if required.
  ThemeHelper().changeTheme('primary');
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
   const MyApp({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: theme,
      title: 'anabathula_s_application2',
      debugShowCheckedModeBanner: false,
      initialRoute: AppRoutes.appHomeScreen,
      home: const SignInScreen(),
      routes: AppRoutes.routes,
    );
  }
}
