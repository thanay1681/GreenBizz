import 'package:anabathula_s_application2/core/app_export.dart';
import 'package:anabathula_s_application2/widgets/custom_elevated_button.dart';
import 'package:anabathula_s_application2/widgets/custom_outlined_button.dart';
import 'package:flutter/material.dart';

class AppHomeScreen extends StatelessWidget {
  const AppHomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            body: SizedBox(
                width: 375.h,
                child: Column(children: [
                  SizedBox(height: 84.v),
                  Expanded(
                      child: SingleChildScrollView(
                          child: Padding(
                              padding: EdgeInsets.only(
                                  left: 22.h, right: 22.h, bottom: 28.v),
                              child: Column(children: [
                                Container(
                                    margin:
                                        EdgeInsets.symmetric(horizontal: 26.h),
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 50.h, vertical: 5.v),
                                    decoration: AppDecoration.fillGreen
                                        .copyWith(
                                            borderRadius: BorderRadiusStyle
                                                .roundedBorder20),
                                    child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: [
                                          SizedBox(height: 14.v),
                                          SizedBox(
                                              width: 174.h,
                                              child: RichText(
                                                  text: TextSpan(children: [
                                                    TextSpan(
                                                        text: "EcoHarvest\n",
                                                        style: CustomTextStyles
                                                            .headlineLargeRobotoBlack900),
                                                    TextSpan(
                                                        text:
                                                            "Trash to Treasure",
                                                        style: CustomTextStyles
                                                            .titleLargeRoboto)
                                                  ]),
                                                  textAlign: TextAlign.center))
                                        ])),
                                SizedBox(height: 317.v),
                                CustomElevatedButton(
                                    text: "👤 User",
                                    onPressed: () {
                                      onTapUser(context);
                                    }),
                                SizedBox(height: 15.v),
                                CustomOutlinedButton(
                                    text: "👤 Worker ",
                                    onPressed: () {
                                      onTapWorker(context);
                                    }),
                                SizedBox(height: 141.v),
                                Text("Continue as a guest",
                                    style: CustomTextStyles
                                        .titleSmallCyan400Bold
                                        .copyWith(
                                            decoration:
                                                TextDecoration.underline))
                              ]))))
                ]))));
  }

  /// Navigates to the customerLoginScreen when the action is triggered.
  onTapUser(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.customerLoginScreen);
  }

  /// Navigates to the employeeLoginScreen when the action is triggered.
  onTapWorker(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.employeeLoginScreen);
  }
}
