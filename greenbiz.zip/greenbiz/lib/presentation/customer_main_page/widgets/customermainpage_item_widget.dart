import 'package:anabathula_s_application2/core/app_export.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class CustomermainpageItemWidget extends StatelessWidget {
  const CustomermainpageItemWidget({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(4.h),
      decoration: AppDecoration.fillGreen.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder14,
      ),
      width: 101.h,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.only(bottom: 89.v),
            child: Column(
              children: [
                Container(
                  height: 4.adaptSize,
                  width: 4.adaptSize,
                  decoration: BoxDecoration(
                    color: appTheme.blueGray100,
                    borderRadius: BorderRadius.circular(
                      2.h,
                    ),
                    border: Border.all(
                      color: appTheme.black900,
                      width: 1.h,
                    ),
                  ),
                ),
                Container(
                  height: 3.v,
                  width: 8.h,
                  decoration: BoxDecoration(
                    color: appTheme.blueGray100,
                    borderRadius: BorderRadius.circular(
                      4.h,
                    ),
                    border: Border.all(
                      color: appTheme.black900,
                      width: 1.h,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: EdgeInsets.only(
              left: 2.h,
              bottom: 6.v,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "20381",
                  style: theme.textTheme.labelMedium,
                ),
                SizedBox(height: 2.v),
                CustomImageView(
                  imagePath: ImageConstant.imgEllipse4,
                  height: 36.v,
                  width: 40.h,
                  radius: BorderRadius.circular(
                    20.h,
                  ),
                  alignment: Alignment.center,
                ),
                SizedBox(height: 7.v),
                Padding(
                  padding: EdgeInsets.only(left: 8.h),
                  child: Row(
                    children: [
                      CustomImageView(
                        imagePath: ImageConstant.imgSubtract,
                        height: 11.v,
                        width: 13.h,
                        margin: EdgeInsets.only(bottom: 2.v),
                      ),
                      Padding(
                        padding: EdgeInsets.only(left: 2.h),
                        child: Text(
                          "400",
                          style: theme.textTheme.labelMedium,
                        ),
                      ),
                    ],
                  ),
                ),
                Align(
                  alignment: Alignment.centerRight,
                  child: Container(
                    margin: EdgeInsets.only(left: 8.h),
                    padding: EdgeInsets.symmetric(horizontal: 17.h),
                    decoration: AppDecoration.fillLightGreenA.copyWith(
                      borderRadius: BorderRadiusStyle.roundedBorder8,
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SizedBox(height: 4.v),
                        Align(
                          alignment: Alignment.centerRight,
                          child: SizedBox(
                            child: Divider(),
                          ),
                        ),
                        SizedBox(height: 1.v),
                        SizedBox(
                          width: 17.h,
                          child: Divider(),
                        ),
                        SizedBox(height: 1.v),
                        SizedBox(
                          width: 17.h,
                          child: Divider(),
                        ),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: SizedBox(
                            child: Divider(),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
