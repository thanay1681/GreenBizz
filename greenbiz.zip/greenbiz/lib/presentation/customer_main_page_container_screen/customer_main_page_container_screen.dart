import 'package:anabathula_s_application2/core/app_export.dart';
import 'package:anabathula_s_application2/presentation/customer_main_page/customer_main_page.dart';
import 'package:anabathula_s_application2/presentation/worker_home_page/worker_home_page.dart';
import 'package:anabathula_s_application2/widgets/custom_bottom_bar.dart';
import 'package:flutter/material.dart';

// ignore_for_file: must_be_immutable
class CustomerMainPageContainerScreen extends StatelessWidget {
  CustomerMainPageContainerScreen({Key? key}) : super(key: key);

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            backgroundColor: theme.colorScheme.onErrorContainer.withOpacity(1),
            body: Navigator(
                key: navigatorKey,
                initialRoute: AppRoutes.customerMainPage,
                onGenerateRoute: (routeSetting) => PageRouteBuilder(
                    pageBuilder: (ctx, ani, ani1) =>
                        getCurrentPage(routeSetting.name!),
                    transitionDuration: Duration(seconds: 0))),
            bottomNavigationBar: _buildBottomBar(context)));
  }

  /// Section Widget
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(onChanged: (BottomBarEnum type) {
      Navigator.pushNamed(navigatorKey.currentContext!, getCurrentRoute(type));
    });
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Image12:
        return AppRoutes.customerMainPage;
      case BottomBarEnum.Image13:
        return AppRoutes.workerHomePage;
      case BottomBarEnum.Image14:
        return "/";
      case BottomBarEnum.Image15:
        return "/";
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.customerMainPage:
        return CustomerMainPage();
      case AppRoutes.workerHomePage:
        return WorkerHomePage();
      default:
        return DefaultWidget();
    }
  }
}
