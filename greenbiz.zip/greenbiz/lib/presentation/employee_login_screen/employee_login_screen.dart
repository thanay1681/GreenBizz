import 'package:anabathula_s_application2/core/app_export.dart';
import 'package:anabathula_s_application2/widgets/custom_elevated_button.dart';
import 'package:flutter/material.dart';

class EmployeeLoginScreen extends StatelessWidget {
  const EmployeeLoginScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            body: SizedBox(
                width: 375.h,
                child: Column(children: [
                  SizedBox(height: 84.v),
                  Expanded(
                      child: SingleChildScrollView(
                          child: Padding(
                              padding: EdgeInsets.only(
                                  left: 22.h, right: 22.h, bottom: 258.v),
                              child: Column(children: [
                                Container(
                                    margin:
                                        EdgeInsets.symmetric(horizontal: 26.h),
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 50.h, vertical: 5.v),
                                    decoration: AppDecoration.fillGreen
                                        .copyWith(
                                            borderRadius: BorderRadiusStyle
                                                .roundedBorder20),
                                    child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: [
                                          SizedBox(height: 14.v),
                                          SizedBox(
                                              width: 174.h,
                                              child: RichText(
                                                  text: TextSpan(children: [
                                                    TextSpan(
                                                        text: "EcoHarvest\n",
                                                        style: CustomTextStyles
                                                            .headlineLargeRobotoBlack900),
                                                    TextSpan(
                                                        text:
                                                            "Trash to Treasure",
                                                        style: CustomTextStyles
                                                            .titleLargeRoboto)
                                                  ]),
                                                  textAlign: TextAlign.center))
                                        ])),
                                SizedBox(height: 317.v),
                                CustomElevatedButton(
                                    text: "Login",
                                    onPressed: () {
                                      onTapLogin(context);
                                    })
                              ]))))
                ]))));
  }

  /// Navigates to the loginScreen when the action is triggered.
  onTapLogin(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.loginScreen);
  }
}
