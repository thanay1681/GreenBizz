import 'package:anabathula_s_application2/core/app_export.dart';
import 'package:anabathula_s_application2/widgets/app_bar/appbar_leading_image.dart';
import 'package:anabathula_s_application2/widgets/app_bar/appbar_title.dart';
import 'package:anabathula_s_application2/widgets/app_bar/custom_app_bar.dart';
import 'package:anabathula_s_application2/widgets/custom_elevated_button.dart';
import 'package:anabathula_s_application2/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';

// ignore_for_file: must_be_immutable
class FrameTwoScreen extends StatelessWidget {
  FrameTwoScreen({Key? key}) : super(key: key);

  TextEditingController earningsEditTextController = TextEditingController();

  TextEditingController faqsEditTextController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            backgroundColor: appTheme.green800,
            resizeToAvoidBottomInset: false,
            appBar: _buildAppBar(context),
            body: Container(
                width: 269.h,
                padding: EdgeInsets.symmetric(horizontal: 15.h, vertical: 29.v),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildProfileSettingsButton(context),
                      SizedBox(height: 28.v),
                      _buildEarningsEditText(context),
                      SizedBox(height: 28.v),
                      _buildFaqsEditText(context),
                      SizedBox(height: 28.v),
                      _buildLogoutButton(context),
                      SizedBox(height: 5.v)
                    ]))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
        height: 54.v,
        leadingWidth: 50.h,
        leading: AppbarLeadingImage(
            imagePath: ImageConstant.imgUser,
            margin: EdgeInsets.only(left: 10.h, top: 7.v, bottom: 7.v)),
        centerTitle: true,
        title: AppbarTitle(text: "Hello User"));
  }

  /// Section Widget
  Widget _buildProfileSettingsButton(BuildContext context) {
    return CustomElevatedButton(
        height: 36.v,
        text: "Profile Settings",
        margin: EdgeInsets.only(right: 53.h),
        buttonStyle: CustomButtonStyles.fillLightGreen,
        buttonTextStyle: CustomTextStyles.titleLargeInriaSans,
        onPressed: () {
          onTapProfileSettingsButton(context);
        });
  }

  /// Section Widget
  Widget _buildEarningsEditText(BuildContext context) {
    return Padding(
        padding: EdgeInsets.only(right: 53.h),
        child: CustomTextFormField(
            controller: earningsEditTextController,
            hintText: "Earnings",
            contentPadding:
                EdgeInsets.symmetric(horizontal: 23.h, vertical: 5.v),
            borderDecoration: TextFormFieldStyleHelper.fillLightGreen,
            fillColor: appTheme.lightGreen100));
  }

  /// Section Widget
  Widget _buildFaqsEditText(BuildContext context) {
    return Padding(
        padding: EdgeInsets.only(right: 53.h),
        child: CustomTextFormField(
            controller: faqsEditTextController,
            hintText: "FAQ’s",
            textInputAction: TextInputAction.done,
            contentPadding:
                EdgeInsets.symmetric(horizontal: 23.h, vertical: 5.v),
            borderDecoration: TextFormFieldStyleHelper.fillLightGreen,
            fillColor: appTheme.lightGreen100));
  }

  /// Section Widget
  Widget _buildLogoutButton(BuildContext context) {
    return CustomElevatedButton(
        height: 36.v,
        text: "Logout",
        margin: EdgeInsets.only(right: 53.h),
        buttonStyle: CustomButtonStyles.fillLightGreen,
        buttonTextStyle: CustomTextStyles.titleLargeInriaSans,
        onPressed: () {
          onTapLogoutButton(context);
        });
  }

  /// Navigates to the profileScreen when the action is triggered.
  onTapProfileSettingsButton(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.profileScreen);
  }

  /// Navigates to the loginScreen when the action is triggered.
  onTapLogoutButton(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.loginScreen);
  }
}
