import 'package:anabathula_s_application2/core/app_export.dart';
import 'package:anabathula_s_application2/widgets/custom_elevated_button.dart';
import 'package:anabathula_s_application2/widgets/custom_icon_button.dart';
import 'package:anabathula_s_application2/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg_provider/flutter_svg_provider.dart' as fs;

// ignore_for_file: must_be_immutable
class LoginScreen extends StatelessWidget {
  LoginScreen({Key? key}) : super(key: key);

  TextEditingController emailController = TextEditingController();

  TextEditingController passwordController = TextEditingController();

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            backgroundColor: appTheme.green800,
            resizeToAvoidBottomInset: false,
            body: Form(
                key: _formKey,
                child: SizedBox(
                    height: 783.v,
                    width: 375.h,
                    child: Stack(alignment: Alignment.center, children: [
                      CustomImageView(
                          imagePath: ImageConstant.imgStatusBar,
                          height: 785.v,
                          width: 375.h,
                          alignment: Alignment.center),
                      Align(
                          alignment: Alignment.center,
                          child: SingleChildScrollView(
                              child: Container(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 21.h, vertical: 42.v),
                                  decoration: BoxDecoration(
                                      image: DecorationImage(
                                          image: fs.Svg(
                                              ImageConstant.imgStatusBar),
                                          fit: BoxFit.cover)),
                                  child: Column(children: [
                                    Padding(
                                        padding: EdgeInsets.only(left: 15.h),
                                        child: CustomIconButton(
                                            height: 41.adaptSize,
                                            width: 41.adaptSize,
                                            padding: EdgeInsets.all(10.h),
                                            alignment: Alignment.centerLeft,
                                            onTap: () {
                                              onTapBtnArrowLeft(context);
                                            },
                                            child: CustomImageView(
                                                imagePath: ImageConstant
                                                    .imgArrowLeft))),
                                    SizedBox(height: 38.v),
                                    Align(
                                        alignment: Alignment.centerLeft,
                                        child: Text("Login",
                                            style:
                                                theme.textTheme.headlineLarge)),
                                    SizedBox(height: 93.v),
                                    CustomTextFormField(
                                        controller: emailController,
                                        hintText: "Enter your email",
                                        textInputType:
                                            TextInputType.emailAddress),
                                    SizedBox(height: 15.v),
                                    CustomTextFormField(
                                        controller: passwordController,
                                        hintText: "Enter your password",
                                        textInputAction: TextInputAction.done,
                                        textInputType:
                                            TextInputType.visiblePassword,
                                        suffix: Container(
                                            margin: EdgeInsets.fromLTRB(
                                                12.h, 17.v, 9.h, 17.v),
                                            decoration: BoxDecoration(
                                                borderRadius:
                                                    BorderRadius.circular(8.h)),
                                            child: CustomImageView(
                                                imagePath: ImageConstant
                                                    .imgFluenteye20filled,
                                                height: 22.v,
                                                width: 21.h)),
                                        suffixConstraints:
                                            BoxConstraints(maxHeight: 56.v),
                                        obscureText: true,
                                        contentPadding: EdgeInsets.only(
                                            left: 20.h,
                                            top: 19.v,
                                            bottom: 19.v)),
                                    SizedBox(height: 6.v),
                                    Align(
                                        alignment: Alignment.centerRight,
                                        child: Text("Forgot Password?",
                                            style: CustomTextStyles
                                                .titleSmallGray600)),
                                    SizedBox(height: 67.v),
                                    CustomElevatedButton(text: "Login"),
                                    SizedBox(height: 31.v),
                                    _buildLoginWithSection(context),
                                    SizedBox(height: 21.v),
                                    _buildSocialMediaSection(context),
                                    SizedBox(height: 91.v)
                                  ]))))
                    ])))));
  }

  /// Section Widget
  Widget _buildLoginWithSection(BuildContext context) {
    return Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Padding(
          padding: EdgeInsets.symmetric(vertical: 8.v),
          child:
              SizedBox(width: 111.h, child: Divider(color: appTheme.indigo50))),
      Text("Or Login with", style: CustomTextStyles.titleSmallGray600),
      Padding(
          padding: EdgeInsets.symmetric(vertical: 8.v),
          child:
              SizedBox(width: 110.h, child: Divider(color: appTheme.indigo50)))
    ]);
  }

  /// Section Widget
  Widget _buildSocialMediaSection(BuildContext context) {
    return Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Container(
          height: 56.v,
          width: 105.h,
          padding: EdgeInsets.symmetric(horizontal: 38.h, vertical: 14.v),
          decoration: AppDecoration.outlineGray
              .copyWith(borderRadius: BorderRadiusStyle.roundedBorder8),
          child: CustomImageView(
              imagePath: ImageConstant.imgFacebookIc,
              height: 26.adaptSize,
              width: 26.adaptSize,
              alignment: Alignment.center)),
      Container(
          height: 56.v,
          width: 105.h,
          padding: EdgeInsets.symmetric(horizontal: 38.h, vertical: 14.v),
          decoration: AppDecoration.outlineGray
              .copyWith(borderRadius: BorderRadiusStyle.roundedBorder8),
          child: CustomImageView(
              imagePath: ImageConstant.imgGoogleIc,
              height: 26.adaptSize,
              width: 26.adaptSize,
              alignment: Alignment.center)),
      Container(
          height: 56.v,
          width: 105.h,
          padding: EdgeInsets.symmetric(horizontal: 38.h, vertical: 14.v),
          decoration: AppDecoration.outlineGray
              .copyWith(borderRadius: BorderRadiusStyle.roundedBorder8),
          child: CustomImageView(
              imagePath: ImageConstant.imgCibApple,
              height: 26.adaptSize,
              width: 26.adaptSize,
              alignment: Alignment.center))
    ]);
  }

  /// Navigates back to the previous screen.
  onTapBtnArrowLeft(BuildContext context) {
    Navigator.pop(context);
  }
}
