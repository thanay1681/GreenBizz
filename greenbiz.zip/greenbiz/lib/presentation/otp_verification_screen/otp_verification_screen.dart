import 'package:anabathula_s_application2/core/app_export.dart';
import 'package:anabathula_s_application2/widgets/app_bar/appbar_leading_iconbutton.dart';
import 'package:anabathula_s_application2/widgets/app_bar/custom_app_bar.dart';
import 'package:anabathula_s_application2/widgets/custom_elevated_button.dart';
import 'package:anabathula_s_application2/widgets/custom_pin_code_text_field.dart';
import 'package:flutter/material.dart';

class OtpVerificationScreen extends StatelessWidget {
  const OtpVerificationScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            appBar: _buildAppBar(context),
            body: SizedBox(
                width: mediaQueryData.size.width,
                child: SingleChildScrollView(
                    padding: EdgeInsets.only(top: 19.v),
                    child: Padding(
                        padding: EdgeInsets.only(
                            left: 21.h, right: 21.h, bottom: 5.v),
                        child: Column(children: [
                          Align(
                              alignment: Alignment.centerLeft,
                              child: Text("OTP Verification",
                                  style: theme.textTheme.headlineLarge)),
                          SizedBox(height: 14.v),
                          SizedBox(
                              width: 329.h,
                              child: Text(
                                  "Enter the verification code we just sent on your email address.",
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: theme.textTheme.titleMedium!
                                      .copyWith(height: 1.50))),
                          SizedBox(height: 55.v),
                          Padding(
                              padding: EdgeInsets.only(left: 3.h),
                              child: CustomPinCodeTextField(
                                  context: context, onChanged: (value) {})),
                          SizedBox(height: 30.v),
                          CustomElevatedButton(
                              text: "Verify",
                              onPressed: () {
                                onTapVerify(context);
                              }),
                          SizedBox(height: 321.v),
                          RichText(
                              text: TextSpan(children: [
                                TextSpan(
                                    text: "Didn’t received code? ",
                                    style: CustomTextStyles.titleSmallPrimary),
                                TextSpan(
                                    text: "Resend",
                                    style: CustomTextStyles.titleSmallCyan400)
                              ]),
                              textAlign: TextAlign.left)
                        ]))))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
        leadingWidth: 375.h,
        leading: AppbarLeadingIconbutton(
            imagePath: ImageConstant.imgArrowLeft,
            margin: EdgeInsets.fromLTRB(36.h, 7.v, 298.h, 7.v),
            onTap: () {
              onTapArrowLeft(context);
            }));
  }

  /// Navigates back to the previous screen.
  onTapArrowLeft(BuildContext context) {
    Navigator.pop(context);
  }

  /// Navigates to the resetPasswordScreen when the action is triggered.
  onTapVerify(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.resetPasswordScreen);
  }
}
