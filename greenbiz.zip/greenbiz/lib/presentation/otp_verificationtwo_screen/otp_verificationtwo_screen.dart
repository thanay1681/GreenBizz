import 'package:anabathula_s_application2/core/app_export.dart';
import 'package:anabathula_s_application2/widgets/app_bar/appbar_leading_iconbutton.dart';
import 'package:anabathula_s_application2/widgets/app_bar/custom_app_bar.dart';
import 'package:anabathula_s_application2/widgets/custom_elevated_button.dart';
import 'package:anabathula_s_application2/widgets/custom_pin_code_text_field.dart';
import 'package:flutter/material.dart';

class OtpVerificationtwoScreen extends StatelessWidget {
  const OtpVerificationtwoScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            backgroundColor: appTheme.green800,
            resizeToAvoidBottomInset: false,
            appBar: _buildAppBar(context),
            body: SizedBox(
                width: mediaQueryData.size.width,
                child: SingleChildScrollView(
                    padding: EdgeInsets.only(top: 19.v),
                    child: _buildOtpVerification(context)))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
        leadingWidth: double.maxFinite,
        leading: AppbarLeadingIconbutton(
            imagePath: ImageConstant.imgArrowLeft,
            margin: EdgeInsets.fromLTRB(27.h, 7.v, 292.h, 7.v),
            onTap: () {
              onTapArrowLeft(context);
            }));
  }

  /// Section Widget
  Widget _buildOtpVerification(BuildContext context) {
    return Container(
        margin: EdgeInsets.only(left: 11.h, right: 16.h, bottom: 5.v),
        decoration: AppDecoration.fillLightGreen,
        child: Column(children: [
          Align(
              alignment: Alignment.centerLeft,
              child: Text("OTP Verification",
                  style: theme.textTheme.headlineLarge)),
          SizedBox(height: 14.v),
          SizedBox(
              width: 329.h,
              child: Text(
                  "Enter the verification code we just sent on your email address.",
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: theme.textTheme.titleMedium!.copyWith(height: 1.50))),
          SizedBox(height: 55.v),
          Padding(
              padding: EdgeInsets.only(left: 3.h),
              child: CustomPinCodeTextField(
                  context: context, onChanged: (value) {})),
          SizedBox(height: 30.v),
          CustomElevatedButton(
              text: "Verify",
              onPressed: () {
                onTapVerify(context);
              })
        ]));
  }

  /// Navigates back to the previous screen.
  onTapArrowLeft(BuildContext context) {
    Navigator.pop(context);
  }

  /// Navigates to the registeredScreen when the action is triggered.
  onTapVerify(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.registeredScreen);
  }
}
