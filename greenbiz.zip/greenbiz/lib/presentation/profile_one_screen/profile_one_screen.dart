import 'package:anabathula_s_application2/core/app_export.dart';
import 'package:anabathula_s_application2/widgets/app_bar/appbar_leading_iconbutton_one.dart';
import 'package:anabathula_s_application2/widgets/app_bar/custom_app_bar.dart';
import 'package:flutter/material.dart';

class ProfileOneScreen extends StatelessWidget {
  const ProfileOneScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            backgroundColor: appTheme.greenA100,
            appBar: _buildAppBar(context),
            body: Container(
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(horizontal: 16.h, vertical: 11.v),
                child: Column(children: [
                  Align(
                      alignment: Alignment.centerLeft,
                      child: Padding(
                          padding: EdgeInsets.only(left: 7.h),
                          child: Row(children: [
                            GestureDetector(
                                onTap: () {
                                  onTapView(context);
                                },
                                child: Container(
                                    height: 45.adaptSize,
                                    width: 45.adaptSize,
                                    decoration: BoxDecoration(
                                        color: appTheme.blueGray100,
                                        borderRadius:
                                            BorderRadius.circular(22.h)))),
                            Padding(
                                padding: EdgeInsets.only(
                                    left: 14.h, top: 9.v, bottom: 5.v),
                                child: Text("Hello User",
                                    style: theme.textTheme.headlineSmall))
                          ]))),
                  SizedBox(height: 27.v),
                  Align(
                      alignment: Alignment.centerLeft,
                      child: Padding(
                          padding: EdgeInsets.only(left: 3.h),
                          child: Text("Basic Info",
                              style: theme.textTheme.headlineSmall))),
                  SizedBox(height: 15.v),
                  _buildSixtyFour(context, phoneNumber: "Name\nThanay Sisir"),
                  SizedBox(height: 8.v),
                  _buildSixtyFour(context,
                      phoneNumber: "Phone Number\n+91 9876543210"),
                  SizedBox(height: 4.v),
                  _buildSixtyFour(context,
                      phoneNumber: "Email\n9876543210@gmail.com"),
                  SizedBox(height: 5.v)
                ]))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
        leadingWidth: double.maxFinite,
        leading: AppbarLeadingIconbuttonOne(
            imagePath: ImageConstant.imgArrowLeft,
            margin: EdgeInsets.fromLTRB(8.h, 7.v, 311.h, 8.v),
            onTap: () {
              onTapArrowLeft(context);
            }));
  }

  /// Common widget
  Widget _buildSixtyFour(
    BuildContext context, {
    required String phoneNumber,
  }) {
    return SizedBox(
        height: 33.v,
        width: 321.h,
        child: Stack(alignment: Alignment.bottomCenter, children: [
          Align(
              alignment: Alignment.centerLeft,
              child: SizedBox(
                  width: 99.h,
                  child: RichText(
                      text: TextSpan(children: [
                        TextSpan(
                            text: "Phone Number\n",
                            style: theme.textTheme.bodyMedium),
                        TextSpan(
                            text: "+91 9876543210",
                            style: theme.textTheme.bodySmall)
                      ]),
                      textAlign: TextAlign.left))),
          Align(
              alignment: Alignment.bottomCenter,
              child: SizedBox(
                  width: 321.h, child: Divider(color: appTheme.gray500)))
        ]));
  }

  /// Navigates back to the previous screen.
  onTapArrowLeft(BuildContext context) {
    Navigator.pop(context);
  }

  /// Navigates to the profilePicOneScreen when the action is triggered.
  onTapView(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.profilePicOneScreen);
  }
}
