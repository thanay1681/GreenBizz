import 'package:anabathula_s_application2/core/app_export.dart';
import 'package:anabathula_s_application2/widgets/custom_drop_down.dart';
import 'package:anabathula_s_application2/widgets/custom_icon_button.dart';
import 'package:flutter/material.dart';

class StatusScreen extends StatelessWidget {
  StatusScreen({Key? key})
      : super(
          key: key,
        );

  List<String> dropdownItemList = [
    "Item One",
    "Item Two",
    "Item Three",
  ];

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return SafeArea(
      child: Scaffold(
        backgroundColor: theme.colorScheme.onErrorContainer.withOpacity(1),
        body: SizedBox(
          height: mediaQueryData.size.height,
          width: double.maxFinite,
          child: Stack(
            alignment: Alignment.bottomCenter,
            children: [
              Align(
                alignment: Alignment.center,
                child: Container(
                  padding: EdgeInsets.symmetric(
                    horizontal: 9.h,
                    vertical: 23.v,
                  ),
                  decoration: AppDecoration.fillLightGreen,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: 4.v),
                      Container(
                        decoration: AppDecoration.outlineBlack900,
                        child: Text(
                          "Pick Up At",
                          style: CustomTextStyles.headlineLargeInterBlack900,
                        ),
                      ),
                      Spacer(),
                      CustomImageView(
                        imagePath: ImageConstant.imgImage5,
                        height: 83.v,
                        width: 339.h,
                      ),
                      SizedBox(height: 42.v),
                      Padding(
                        padding: EdgeInsets.only(
                          left: 13.h,
                          right: 27.h,
                        ),
                        child: CustomDropDown(
                          icon: Container(
                            margin: EdgeInsets.fromLTRB(30.h, 18.v, 14.h, 18.v),
                            child: CustomImageView(
                              imagePath: ImageConstant.imgArrow1,
                              height: 3.v,
                              width: 35.h,
                            ),
                          ),
                          hintText: "Pickup Done",
                          items: dropdownItemList,
                          onChanged: (value) {},
                        ),
                      ),
                      SizedBox(height: 53.v),
                      Padding(
                        padding: EdgeInsets.only(left: 98.h),
                        child: CustomIconButton(
                          height: 42.v,
                          width: 103.h,
                          child: CustomImageView(
                            imagePath: ImageConstant.imgImage1542x103,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              _buildCustomerAddress(context),
              CustomImageView(
                imagePath: ImageConstant.imgFrame41,
                height: 256.v,
                width: 360.h,
                alignment: Alignment.topCenter,
                margin: EdgeInsets.only(top: 78.v),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildCustomerAddress(BuildContext context) {
    return Align(
      alignment: Alignment.bottomCenter,
      child: Padding(
        padding: EdgeInsets.only(
          left: 5.h,
          bottom: 308.v,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Customer’s Address",
              style: theme.textTheme.bodyLarge,
            ),
            SizedBox(height: 10.v),
            Container(
              width: 355.h,
              padding: EdgeInsets.symmetric(
                horizontal: 18.h,
                vertical: 3.v,
              ),
              decoration: AppDecoration.fillGreen,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(height: 2.v),
                  Container(
                    width: 250.h,
                    margin: EdgeInsets.only(right: 68.h),
                    child: Text(
                      "1-141F-52,Wall Street,San Fransisco,United States of America",
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                      style: CustomTextStyles.titleLargeRegular,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
