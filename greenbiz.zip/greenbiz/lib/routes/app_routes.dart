import 'package:flutter/material.dart';
import 'package:anabathula_s_application2/presentation/app_home_screen/app_home_screen.dart';
import 'package:anabathula_s_application2/presentation/login_one_screen/login_one_screen.dart';
import 'package:anabathula_s_application2/presentation/register_screen/register_screen.dart';
import 'package:anabathula_s_application2/presentation/otp_verificationtwo_screen/otp_verificationtwo_screen.dart';
import 'package:anabathula_s_application2/presentation/registered_screen/registered_screen.dart';
import 'package:anabathula_s_application2/presentation/pickup_details_screen/pickup_details_screen.dart';
import 'package:anabathula_s_application2/presentation/customer_login_screen/customer_login_screen.dart';
import 'package:anabathula_s_application2/presentation/details_confirmation_screen/details_confirmation_screen.dart';
import 'package:anabathula_s_application2/presentation/pickup_confirmed_screen/pickup_confirmed_screen.dart';
import 'package:anabathula_s_application2/presentation/otp_verification_screen/otp_verification_screen.dart';
import 'package:anabathula_s_application2/presentation/reset_password_screen/reset_password_screen.dart';
import 'package:anabathula_s_application2/presentation/password_changed_screen/password_changed_screen.dart';
import 'package:anabathula_s_application2/presentation/customer_main_page_container_screen/customer_main_page_container_screen.dart';
import 'package:anabathula_s_application2/presentation/more_screen/more_screen.dart';
import 'package:anabathula_s_application2/presentation/grievence_screen/grievence_screen.dart';
import 'package:anabathula_s_application2/presentation/profile_one_screen/profile_one_screen.dart';
import 'package:anabathula_s_application2/presentation/profile_pic_one_screen/profile_pic_one_screen.dart';
import 'package:anabathula_s_application2/presentation/profile_screen/profile_screen.dart';
import 'package:anabathula_s_application2/presentation/frame_two_screen/frame_two_screen.dart';
import 'package:anabathula_s_application2/presentation/status_screen/status_screen.dart';
import 'package:anabathula_s_application2/presentation/employee_login_screen/employee_login_screen.dart';
import 'package:anabathula_s_application2/presentation/login_screen/login_screen.dart';
import 'package:anabathula_s_application2/presentation/unloading_of_trash_screen/unloading_of_trash_screen.dart';
import 'package:anabathula_s_application2/presentation/profile_pic_screen/profile_pic_screen.dart';
import 'package:anabathula_s_application2/presentation/app_navigation_screen/app_navigation_screen.dart';

class AppRoutes {
  static const String appHomeScreen = '/app_home_screen';

  static const String loginOneScreen = '/login_one_screen';

  static const String registerScreen = '/register_screen';

  static const String otpVerificationtwoScreen = '/otp_verificationtwo_screen';

  static const String registeredScreen = '/registered_screen';

  static const String pickupDetailsScreen = '/pickup_details_screen';

  static const String customerLoginScreen = '/customer_login_screen';

  static const String detailsConfirmationScreen =
      '/details_confirmation_screen';

  static const String pickupConfirmedScreen = '/pickup_confirmed_screen';

  static const String otpVerificationScreen = '/otp_verification_screen';

  static const String resetPasswordScreen = '/reset_password_screen';

  static const String passwordChangedScreen = '/password_changed_screen';

  static const String customerMainPage = '/customer_main_page';

  static const String customerMainPageContainerScreen =
      '/customer_main_page_container_screen';

  static const String moreScreen = '/more_screen';

  static const String grievenceScreen = '/grievence_screen';

  static const String profileOneScreen = '/profile_one_screen';

  static const String profilePicOneScreen = '/profile_pic_one_screen';

  static const String profileScreen = '/profile_screen';

  static const String workerHomePage = '/worker_home_page';

  static const String frameTwoScreen = '/frame_two_screen';

  static const String statusScreen = '/status_screen';

  static const String employeeLoginScreen = '/employee_login_screen';

  static const String loginScreen = '/login_screen';

  static const String unloadingOfTrashScreen = '/unloading_of_trash_screen';

  static const String profilePicScreen = '/profile_pic_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static Map<String, WidgetBuilder> routes = {
    appHomeScreen: (context) => AppHomeScreen(),
    loginOneScreen: (context) => LoginOneScreen(),
    registerScreen: (context) => RegisterScreen(),
    otpVerificationtwoScreen: (context) => OtpVerificationtwoScreen(),
    registeredScreen: (context) => RegisteredScreen(),
    pickupDetailsScreen: (context) => PickupDetailsScreen(),
    customerLoginScreen: (context) => CustomerLoginScreen(),
    detailsConfirmationScreen: (context) => DetailsConfirmationScreen(),
    pickupConfirmedScreen: (context) => PickupConfirmedScreen(),
    otpVerificationScreen: (context) => OtpVerificationScreen(),
    resetPasswordScreen: (context) => ResetPasswordScreen(),
    passwordChangedScreen: (context) => PasswordChangedScreen(),
    customerMainPageContainerScreen: (context) =>
        CustomerMainPageContainerScreen(),
    moreScreen: (context) => MoreScreen(),
    grievenceScreen: (context) => GrievenceScreen(),
    profileOneScreen: (context) => ProfileOneScreen(),
    profilePicOneScreen: (context) => ProfilePicOneScreen(),
    profileScreen: (context) => ProfileScreen(),
    frameTwoScreen: (context) => FrameTwoScreen(),
    statusScreen: (context) => StatusScreen(),
    employeeLoginScreen: (context) => EmployeeLoginScreen(),
    loginScreen: (context) => LoginScreen(),
    unloadingOfTrashScreen: (context) => UnloadingOfTrashScreen(),
    profilePicScreen: (context) => ProfilePicScreen(),
    appNavigationScreen: (context) => AppNavigationScreen()
  };
}
